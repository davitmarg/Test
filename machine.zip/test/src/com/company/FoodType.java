package com.company;

public enum FoodType {
    DRINKS,
    CHIPS,
    CHOCOLATE
}
