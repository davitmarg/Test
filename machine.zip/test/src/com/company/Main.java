package com.company;
import com.company.products.*;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Machine machine = new Machine();
        String commandString = in.nextLine();
        Command command = new Command(commandString);
        ArrayList<Food> arr = machine.getProduct(command);
        for(int i=0;i<arr.size();i++)
            System.out.println(i+" : "+arr.get(i));
    }
}
