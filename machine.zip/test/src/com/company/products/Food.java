package com.company.products;

public class Food {
}
