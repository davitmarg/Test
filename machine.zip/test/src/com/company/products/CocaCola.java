package com.company.products;

public class CocaCola extends  Food {
}
