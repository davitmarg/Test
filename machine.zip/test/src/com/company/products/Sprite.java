package com.company.products;

public class Sprite extends  Food {
}
