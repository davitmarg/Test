package com.company.products;

public class Fanta extends  Food {
}
