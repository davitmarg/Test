package com.company.products;

public class Twix extends  Food {
}
