package com.company.products;

public class Doritos extends  Food {
}
