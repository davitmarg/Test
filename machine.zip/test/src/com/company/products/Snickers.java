package com.company.products;

public class Snickers extends  Food {
}
