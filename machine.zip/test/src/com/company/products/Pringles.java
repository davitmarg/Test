package com.company.products;

public class Pringles extends  Food {
}
