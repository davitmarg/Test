package com.company.products;

public class Lays extends  Food {
}
