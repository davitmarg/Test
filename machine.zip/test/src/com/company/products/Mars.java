package com.company.products;

public class Mars extends  Food {
}
